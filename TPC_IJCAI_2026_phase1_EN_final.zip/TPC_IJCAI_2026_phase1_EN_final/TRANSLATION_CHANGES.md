# Phase 1 English Query Changes

## Summary

- Total JSON records: 1000
- Modified JSON records: 18
- Modified field values: 18
- Unchanged JSON records: 982
- Modified field in every listed record: `nature_language`
- Modified `hard_logic_py` fields: 0
- Modified UID or trip-metadata fields: 0

The final dataset was rebuilt from `TPC_IJCAI_2026_phase1_EN`.
The earlier broad LLM repair output was not used. Exactly the records
listed below differ from the original dataset, and each differs only in
its `nature_language` value.

## Complete Change List

### idx=63 - `20250321114239878527`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 2 people, departing from Shanghai, traveling to Chongqing for 3 days, with the following requirements: do not want to visit Holy Name Happy Water World, want
```

**After**

```text
We are 2 people, departing from Shanghai, traveling to Chongqing for 3 days, with the following requirements: we do not want to visit Holy Name Happy Water World, and we want to visit a park.
```

**Reason**

The original ends at "want" and omits the park requirement.

### idx=102 - `20250322001041444207`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 3 people, departing from Wuhan, traveling to Shanghai for
```

**After**

```text
We are 3 people, departing from Wuhan, traveling to Shanghai for 4 days. At least one of the following requirements must be met: (1) visit Xujiahui Origin; or (2) stay at a hotel with a SPA.
```

**Reason**

The original ends after "for" and omits the duration and both OR branches.

### idx=116 - `20250322042822097592`

- Change type: `entity_boundary_error`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 4 people, departing from Shenzhen, traveling to Shanghai for 3 days, with the following requirements:
We want to visit Sightseeing Night Market (Venice Water City Night), Old Wharf, Unicorn Starry Sky Art Museum, and Tianzifang Flagship Store.
We do not want to travel within the city by walking.
```

**After**

```text
We are 4 people, departing from Shenzhen, traveling to Shanghai for 3 days, with the following requirements: we want to visit the following attractions: "Sightseeing Night Market (Venice Water City Night)", "Old Wharf", and "Unicorn Starry Sky Art Museum, Tianzifang Flagship Store". We do not want to travel within the city by walking.
```

**Reason**

The original splits one attraction, "Unicorn Starry Sky Art Museum, Tianzifang Flagship Store", into two attractions.

### idx=237 - `20250322122731296343`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 2 people, departing from Nanjing, traveling to Chengdu for 4 days, and must satisfy any of the following: 1. We hope to visit Amusement Park/Sports Entertainment; 2. We hope to leave Gai
```

**After**

```text
We are 2 people, departing from Nanjing, traveling to Chengdu for 4 days. At least one of the following requirements must be met: (1) visit an Amusement Park/Sports Entertainment attraction; or (2) leave Gaiwan'er Pear Garden • Sichuan Opera Face-Changing and Fire-Spitting Performance Theater • Intangible Cultural Heritage Inheritance Exhibition Base (Tianfu Square Branch) no earlier than 13:50.
```

**Reason**

The second OR branch is truncated inside the attraction name and loses the time constraint.

### idx=241 - `20250322123458076116`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 2 people, departing from Shanghai, traveling to Nanjing for 3 days, and need to meet any one of the following: 1. Want to visit Amusement Park/Sports Entertainment 2. Total budget for
```

**After**

```text
We are 2 people, departing from Shanghai, traveling to Nanjing for 3 days. At least one of the following requirements must be met: (1) visit an Amusement Park/Sports Entertainment attraction; or (2) use a total trip budget of 3300.0.
```

**Reason**

The original ends at "Total budget for" and omits the budget value.

### idx=307 - `20250322143017200261`

- Change type: `entity_boundary_error`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are a group of 4 traveling from Shenzhen to Shanghai for 3 days. We want to try the following restaurants: The Westin Shanghai, Pago Italian Restaurant (Henan Middle Road Branch), Palan Siam Cuisine (University Road Branch), and SHAUGHNESSY Dry-Aged Steakhouse. Our accommodation budget is 16000.0.
```

**After**

```text
We are a group of 4 traveling from Shenzhen to Shanghai for 3 days. We want to try the following restaurants: "The Westin Shanghai, Pago Italian Restaurant (Henan Middle Road Branch)"; "Palan Siam Cuisine (University Road Branch)"; and "SHAUGHNESSY Dry-Aged Steakhouse". Our accommodation budget is 16000.0.
```

**Reason**

The original turns the comma inside the first canonical restaurant name into a list separator, creating four restaurants instead of three.

### idx=322 - `20250322145148244236`

- Change type: `entity_boundary_error`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 4 people, departing from Shenzhen, traveling to Shanghai for 3 days, and need to meet any one of the following:
1. Wish to try the following restaurants: Jinglai Hotel · Selection (Shanghai Xujiahui Jiaotong University Branch), Jingyan Shanghai Cuisine (Nandan Road Branch), De Da Western Restaurant, and Yu Noodle House: Changshu Wild Mushroom Noodle Restaurant
2. Do not wish to travel within the city by walking
```

**After**

```text
We are 4 people, departing from Shenzhen, traveling to Shanghai for 3 days. At least one of the following requirements must be met: (1) try the following restaurants: "Jinglai Hotel · Selection (Shanghai Xujiahui Jiaotong University Branch) · Jingyan Shanghai Cuisine (Nandan Road Branch)", "De Da Western Restaurant", and "Yu Noodle House: Changshu Wild Mushroom Noodle Restaurant"; or (2) do not travel within the city by walking.
```

**Reason**

The original splits the first canonical restaurant name at an internal middle dot.

### idx=383 - `20250322163122317844`

- Change type: `truncation_and_omission`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 5 people traveling from Chongqing to Chengdu for 5 days, with the following requirements: we do not wish to try the restaurant South Pavilion Tea House
```

**After**

```text
We are 5 people traveling from Chongqing to Chengdu for 5 days, with the following requirements: we do not wish to try South Pavilion Tea House Private Custom Tea Banquet, and we wish to stay in a single-bed room.
```

**Reason**

The original truncates the restaurant name and omits the single-bed-room requirement.

### idx=391 - `20250322164349699070`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 1 person, departing from Shenzhen, traveling to
```

**After**

```text
One person is traveling from Shenzhen to Shanghai for 2 days, with the following requirements: try Shanghai Center J Hotel · Jin Yan, Money Shops (Yuyuan Road Branch), and Tasteless Comfort Food (Qibao Branch), and use a total trip budget of 3900.0.
```

**Reason**

The original ends after the destination preposition and omits the destination, duration, restaurant list, and budget.

### idx=463 - `20250322184657638740`

- Change type: `omission`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 3 people traveling from Shanghai to Shenzhen for 4 days
```

**After**

```text
We are 3 people traveling from Shanghai to Shenzhen for 4 days, with the following requirements: do not try seafood restaurants, and stay in a single-bed room.
```

**Reason**

The original contains only the trip header and omits both requirements.

### idx=466 - `20250322185026590450`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 5 people, departing from Shenzhen for a 3-day trip to Suzhou. We need to meet at least one of the following: 1. Dining budget of 190
```

**After**

```text
We are 5 people, departing from Shenzhen for a 3-day trip to Suzhou. At least one of the following requirements must be met: (1) use a dining budget of 1900.0; or (2) stay at a hotel with a sauna.
```

**Reason**

The original truncates 1900.0 to 190 and omits the second OR branch.

### idx=511 - `20250322201135018625`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 4 people traveling from Suzhou to Hangzhou for 4 days, with the following requirements: we want to stay at one of these hotels—Lotus Glade Hotel or H
```

**After**

```text
We are 4 people traveling from Suzhou to Hangzhou for 4 days, with the following requirements: stay at either Lotus Glade Hotel or Hupao Mountain Resort, and choose accommodation that offers free parking.
```

**Reason**

The original is truncated inside the second hotel name. The automatic repair is also invalid because it changes the top-level relation between the named-hotel requirement and free parking from AND to OR.

### idx=534 - `20250322211642316461`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 4 people traveling from Guangzhou to Shanghai for 2 days. It must meet at least one of the following:
1. We wish to stay in a hotel of the type "Family-themed Room".
2. The budget for intercity transportation
```

**After**

```text
We are 4 people traveling from Guangzhou to Shanghai for 2 days. At least one of the following requirements must be met: (1) stay in a hotel offering a Family-themed Room; or (2) use an intercity transportation budget of 6400.0.
```

**Reason**

The original omits the intercity transportation budget value.

### idx=545 - `20250322213744013202`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are
```

**After**

```text
One person is traveling from Beijing to Shenzhen for 3 days. At least one of the following requirements must be met: (1) stay at a hotel with Free parking; or (2) stay in a twin-bed room.
```

**Reason**

The original contains only "We are" and omits all material information.

### idx=549 - `20250322214018148712`

- Change type: `omission`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
One person, departing from Shenzhen, traveling to Shanghai for 2 days, with the following requirements:
```

**After**

```text
One person is traveling from Shenzhen to Shanghai for 2 days, with the following requirements: stay at a hotel with Free parking, do not take a train to the destination, and do not take a train on the return trip.
```

**Reason**

The original stops after the requirements header and omits every requirement. The automatic repair did not change the text.

### idx=627 - `20250323001134684343`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 4 people traveling from Shenzhen to Shanghai for
```

**After**

```text
We are 4 people traveling from Shenzhen to Shanghai for 3 days. At least one of the following requirements must be met: (1) do not travel within the city by taxi; or (2) stay in a single-bed room.
```

**Reason**

The original omits the trip duration and both OR branches.

### idx=643 - `20250323003100968460`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 4 people, traveling from Chongqing to Nanjing for 2 days. We need to satisfy at least one of the following: 1. Do
```

**After**

```text
We are 4 people traveling from Chongqing to Nanjing for 2 days. At least one of the following requirements must be met: (1) do not travel within the city by walking or taxi; or (2) do not take an airplane to the destination and do not take a train on the return trip.
```

**Reason**

The original truncates at the start of the first OR branch and omits both constraints.

### idx=822 - `20250324000430460073`

- Change type: `truncation`
- Modified field: `nature_language`
- Rule audit after modification: `passed`

**Before**

```text
We are 2 people, departing from Wuhan for a 2-day trip to
```

**After**

```text
We are 2 people, departing from Wuhan for a 2-day trip to Chengdu. At least one of the following requirements must be met: (1) leave Tower of Vitality no earlier than 13:50; or (2) stay in a single-bed room.
```

**Reason**

The original is truncated before the destination and omits both OR branches.

## Other Modifications

There are no other dataset modifications. The Markdown file itself is
documentation and is not one of the 1000 UID JSON records.
